import {hasTransportPlans} from './trip-transport-plans-contract.mjs';
import {dayPeople,partyLabel} from './trip-party.mjs?v=1';
import {DAY_INTERESTS,DAY_NEEDS,emptyPreferences,preferencesLabel} from './day-preferences.mjs?v=5';
import {initTripBookings} from './trip-bookings-ui.mjs?v=17';
import {effectiveBookingDay} from './trip-bookings-state.mjs?v=2';
import {initTripExpenses} from './trip-expenses-ui.mjs?v=22';
import {initTripMenuChoices} from './trip-menu-choices-ui.mjs?v=1';
import {serviceBudgetInput} from './trip-service-budget.mjs';
import {journeyDays,selectedDay,chooseTripDay,addTripDay,removeTripDay,movePlaceToDay,changeDayDetails,COST_KINDS} from './trip-days-state.mjs?v=25';
import {parseKopecks,costText,rubles} from './trip-budget-state.mjs?v=2';
import {loadScheduler} from './trip-scheduler.mjs?v=40';
import {loadTripTravelMatrix,TRAVEL_MODES,travelMode} from './travel-estimates.mjs?v=11';
import {mobilityLabel} from './day-mobility.mjs?v=4';
import {isPersonalPoint,baseName} from './personal-points.mjs?v=3';
import {pickPersonalPoint} from './personal-point-picker.mjs?v=6';
import {planInput} from './trip-schedule-state.mjs?v=17';
import {tripStarterChoices,addTripStarter} from './trip-starters.mjs?v=24';
const dateLabel=date=>date?new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'short',timeZone:'UTC'}).format(new Date(date+'T12:00:00Z')):'Дата пока не выбрана';
const clock=n=>`${n>=1440?`+${Math.floor(n/1440)} дн. `:''}${String(Math.floor(n/60)%24).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
const el=(tag,text,className)=>{const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(className)node.className=className;return node;};
const button=(text,action,id)=>{const b=el('button',text,'journey-button');b.type='button';b.dataset.journeyAction=action;if(id)b.dataset.journeyId=id;return b;};
const plural=(n,one,few,many)=>n%100>=11&&n%100<=14?many:n%10===1?one:n%10>=2&&n%10<=4?few:many;
const stopsLabel=n=>`${n} ${plural(n,'остановка','остановки','остановок')}`;
// The overview calculates a route only for days with stops. Empty days still
// retain their dates, bases, bookings and budget without downloading road data.
export function loadJourneyTravelMatrices(base,trip,catalog) {
  return Promise.all(journeyDays(trip).map(day=>day.places.length
    ? loadTripTravelMatrix(base,chooseTripDay(trip,day.id),catalog).catch(()=>null)
    : null));
}
export function initTripDays({mount,read,commit,base,catalog}) {
  if(!mount)return {render(){},moveControl(){return null;}};
  const section=el('section',undefined,'trip-journey');section.setAttribute('aria-labelledby','journey-title');
  section.innerHTML=`<div class="journey-heading"><div><p class="eyebrow">Один день — своё приключение</p><h3 id="journey-title">Ваши дни на Балтике</h3></div><span id="journey-count" class="journey-count"></span></div>
    <details class="journey-starters"><summary>Взять готовый план на 3, 5 или 7 дней <span aria-hidden="true">+</span></summary><div id="journey-starters" class="journey-starter-options"></div><p class="journey-note">Калининград, Зеленоградск и коса. Это основа для вашей поездки: остановки, дни и транспорт можно менять. Дни добавятся к вашему черновику. Переезд между городами в начале дня, адрес жилья, билеты и часы работы уточните отдельно.</p></details>
    <nav id="journey-days" class="journey-days" aria-label="Выбрать день поездки"></nav>
    <div class="journey-tools"><button class="journey-button" type="button" data-journey-action="add">+ Ещё день</button><button class="journey-button" type="button" data-journey-action="copy">Скопировать этот день</button><button class="journey-button journey-delete" type="button" data-journey-action="remove">Удалить день</button></div>
    <details class="wizard-settings wizard-preferences-settings" id="journey-preferences"><summary data-journey-preferences-summary>Интересы и прогулка · выбрать</summary><form id="journey-preferences-form"></form></details>
    <details class="journey-details" id="journey-details"><summary>Начало, ночёвка и бюджет <span aria-hidden="true">+</span></summary><div class="journey-details-body"><form id="journey-bases" class="journey-bases"></form><form id="journey-costs" class="journey-costs"></form></div></details>
    <details class="journey-overview" id="journey-overview"><summary>Вся поездка <span id="journey-total" role="status"></span></summary><p class="journey-note">Время зависит от выбранных остановок, дороги и часов работы. Цены — ваши оценки; пока есть пустые суммы, полный бюджет неизвестен.</p><ol id="journey-overview-days"></ol></details><p id="journey-feedback" class="journey-note" role="status"></p>`;
  (mount.querySelector('.workshop-main') || mount).prepend(section);
  const $=selector=>section.querySelector(selector);let sequence=0;
  const bookings=initTripBookings({section,read,commit,base,catalog});
  const expenses=initTripExpenses({section,read,commit,base,catalog});
  const menuChoices=initTripMenuChoices({mount:section,read,commit,base,catalog});
  $('#journey-starters').replaceChildren(...tripStarterChoices(catalog).map(starter=>{
    if(starter.days.some(day=>['bus','rail'].includes(day.transport))){
      const link=el('a',starter.name);link.href=new URL(`planner/?starter=${encodeURIComponent(starter.id)}`,base);link.className='journey-starter';link.append(el('span',starter.description));return link;
    }
    const b=button(starter.name,'starter',starter.id);b.className='journey-starter';b.append(el('span',starter.description));return b;
  }));
  const feedback=text=>{$('#journey-feedback').textContent=text;};
  function label(form,caption,name,type,value) {
    const wrapper=el('label',caption),field=el(type==='textarea'?'textarea':'input');
    if(type!=='textarea')field.type=type;field.name=name;field.value=value;wrapper.append(field);form.append(wrapper);return field;
  }
  function renderForms(trip) {
    const day=selectedDay(trip),bases=$('#journey-bases'),costs=$('#journey-costs');bases.replaceChildren();costs.replaceChildren();
    const preferences=day.preferences || emptyPreferences(),preferenceForm=$('#journey-preferences-form');preferenceForm.replaceChildren();preferenceForm.dataset.day=day.id;preferenceForm._snapshot=JSON.stringify(day.preferences ?? null);
    $('[data-journey-preferences-summary]').textContent=preferencesLabel(preferences)?`Вам важно: ${preferencesLabel(preferences)} · изменить`:'Интересы и прогулка · выбрать';
    for(const [name,values,title,key]of [['interest',DAY_INTERESTS,'Что хочется увидеть?','interests'],['need',DAY_NEEDS,'Что важно в прогулке?','needs']]) {
      const field=el('fieldset',undefined,'wizard-chips wizard-preference-chips');field.append(el('legend',title));
      for(const [value,text]of Object.entries(values)){const wrapper=el('label'),input=el('input');input.type='checkbox';input.name=name;input.value=value;input.checked=preferences[key].includes(value);wrapper.append(input,el('span',text));field.append(wrapper);}preferenceForm.append(field);
    }
    preferenceForm.append(el('p','Пожелания помогут выбрать следующую прогулку. Сохранённые остановки останутся на месте. Проход без лестниц и с коляской на всём пути ещё нужно проверить.','journey-note'));
    const savePreferences=el('button','Сохранить пожелания','journey-save');savePreferences.type='submit';preferenceForm.append(savePreferences);
    for(const form of [bases,costs])form.dataset.day=day.id;costs._snapshot=JSON.stringify(day.costs);costs._people=dayPeople(day,trip.itinerary?.people || 1);
    bases.append(el('h4','Откуда выйдем, куда вернёмся'));
    for(const [name,caption] of [['start_at','Начать здесь'],['night_at','К ночи вернуться сюда']]) {
      const wrapper=el('div',undefined,'journey-base-field'),captionLabel=el('label',caption),select=el('select');select.name=name;select.id=`journey-${name}`;captionLabel.htmlFor=select.id;wrapper.append(captionLabel);const none=el('option','Пока не выбрано');none.value='';select.append(none);
      for(const place of catalog.poi) {const option=el('option',`${place.name} · ${place.area_name}`);option.value=place.slug;select.append(option);}
      if(isPersonalPoint(day[name])){const own=el('option',day[name].name);own.value='__personal__';select.prepend(own);}
      select.value=isPersonalPoint(day[name])?'__personal__':day[name] || '';wrapper.append(select);
      const pick=button(isPersonalPoint(day[name])?'Передвинуть свою точку на карте':'Выбрать свою точку на карте','personal',name);pick.className='journey-pick-point';wrapper.append(pick);bases.append(wrapper);
    }
    label(bases,'Адрес ночёвки или заметка для себя','note','textarea',day.note).rows=2;
    bases.append(el('p','Выберите ориентир или отметьте своё жильё на нашей карте. Дорога считается по ближайшим доступным улицам и тропам; вход и короткий путь до двери нужно сверить. Свои точки и заметка попадут в файл и ссылку поездки.','journey-note'));
    const saveBases=el('button','Сохранить начало и ночёвку','journey-save');saveBases.type='submit';bases.append(saveBases);
    costs.append(el('h4','Сколько взять с собой'));
    const people=label(costs,'Сколько вас','people','number',dayPeople(day,trip.itinerary?.people || 1));people.min='1';people.max='4294967295';people.step='1';people.required=true;
    costs.append(el('p',day.party?`${partyLabel(day.party)}. Это число относится к выбранному дню. Детские билеты с другой ценой запишите отдельным расходом на всех.`:'Это число используется в днях, где ещё не указан отдельный состав группы.','journey-note'));
    const rows=el('div',undefined,'journey-cost-rows');
    for(const [kind,caption]of Object.entries(COST_KINDS)) {
      const row=el('fieldset',undefined,'journey-cost-row');row.append(el('legend',caption));const cost=day.costs[kind];
      const money=label(row,'Сумма, ₽',`${kind}-amount`,'text',costText(cost?.amount ?? null));money.inputMode='decimal';money.placeholder='Ещё не знаю';
      const qty=label(row,'Количество',`${kind}-quantity`,'number',cost?.quantity || 1);qty.min='1';qty.max='4294967295';qty.step='1';qty.required=true;
      const wrapper=el('label','Эта сумма'),scope=el('select');scope.name=`${kind}-scope`;
      for(const [value,text]of [['group','На всех'],['person','На человека']]) {const option=el('option',text);option.value=value;scope.append(option);}scope.value=cost?.scope || 'group';wrapper.append(scope);row.append(wrapper);
      const basisLabel=el('label','Считать категорию'),basis=el('select');basis.name=`${kind}-basis`;
      for(const [value,text]of [['summary','По общей оценке'],['items','По списку расходов']]){const option=el('option',text);option.value=value;basis.append(option);}basis.value=cost?.basis || 'summary';basisLabel.append(basis);row.append(basisLabel);
      const paid=label(row,'Уже оплачено на всех, ₽',`${kind}-paid`,'text',costText(cost?.paid ?? null));paid.inputMode='decimal';paid.placeholder='Ещё не записано';
      if(basis.value==='items'){const note=el('p','Сейчас считаем по списку расходов. Общая сумма и оплата выше сохранены, но в итог не входят.','journey-note');note.style.gridColumn='1 / -1';row.append(note);}rows.append(row);
    }costs.append(rows);
    costs.append(el('p','Укажите цену и сколько раз её оплачиваете. Пусто — расход ещё неизвестен. Ноль — бесплатно. Все суммы относятся к выбранному дню.','journey-note'));
    const save=el('button','Сохранить оценки','journey-save');save.type='submit';costs.append(save);
    const summary=el('p',undefined,'journey-budget-day');summary.id='journey-budget-day';summary.setAttribute('role','status');costs.append(summary);
  }
  async function renderTotals(trip,ticket) {
    $('#journey-total').textContent='Считаем…';
    try {
      const engine=await loadScheduler(base);if(ticket!==sequence)return;
      const budget=engine.budget(serviceBudgetInput(trip)),forecast=budget.forecast||budget;
      expenses.totals(budget);
      $('#journey-total').textContent=forecast.total===null?`${rubles(forecast.known)} известно · полный бюджет пока неизвестен`:`${rubles(forecast.total)} на всех`+(forecast.varying_people?' · число путешественников различается по дням':` · ${rubles(forecast.per_person)} на человека`);
      const active=forecast.days.find(day=>day.id===selectedDay(trip).id),daySummary=$('#journey-budget-day');
      daySummary.textContent=active.total===null?`Этот день: ${rubles(active.known)} известно. Есть суммы, которые нужно уточнить.`:`Оценка этого дня: ${rubles(active.total)} на всех.`;
      if(journeyDays(trip).some(hasTransportPlans))$('#journey-total').textContent+=' · без отдельных транспортных расчётов';
      if(hasTransportPlans(selectedDay(trip)))daySummary.textContent+=' Транспортный расчёт — отдельно.';
      section.dataset.budgetReady='true';
      const matrices=await loadJourneyTravelMatrices(base,trip,catalog);if(ticket!==sequence)return;
      $('#journey-overview-days').replaceChildren(...journeyDays(trip).map((day,index)=>{
        const li=el('li'),select=button(`День ${index+1} · ${dateLabel(day.date)}`,'choose',day.id);li.append(select);
        const summary=el('p',undefined,'journey-day-note');
        const total=forecast.days.find(row=>row.id===day.id);
        let text=`${partyLabel(day.party)?partyLabel(day.party)+' · ':''}${stopsLabel(day.places.length)} · ${mobilityLabel(chooseTripDay(trip,day.id))}`;
        if(day.places.length) {
          try {
            const result=engine(planInput(chooseTripDay(trip,day.id),catalog,matrices[index]));
            text+=` · ${result.finish===null?'не раньше':'окончание около'} ${clock(result.earliest_finish)}`;
            if(['conflict','overrun'].includes(result.status))text+=' · не всё помещается';
            if(result.finish===null)text+=' · дорогу нужно уточнить';
          }catch(error){if(error.message==='departure_before_day')text+=' · отъезд не оставляет времени этому дню';else if(error.message==='arrival_after_day')text+=' · прибытие позже конца дня';else throw error;}
        }else text+=hasTransportPlans(day)?' · дорога сохранена':' · выберите места';
        text+=total.total===null?` · ${rubles(total.known)} известно`:` · ${rubles(total.total)}`;summary.textContent=text;li.append(summary);if(hasTransportPlans(day))li.append(el('p','Транспортный расчёт показан отдельно; в этот бюджет и время он не входит.','journey-day-note'));
        for(const [field,caption]of [['start_at','От'],['night_at','К ночи']])if(effectiveBookingDay(day)[field])li.append(el('p',`${caption}: ${baseName(effectiveBookingDay(day)[field],catalog)}`,'journey-day-note'));
        return li;
      }));
    }catch(error) {if(ticket!==sequence)return;section.dataset.budgetReady='error';expenses.error();$('#journey-overview-days').replaceChildren();$('#journey-total').textContent=error.message==='budget_overflow'?'Суммы слишком велики для расчёта. Проверьте цены и количество.':'Расчёт пока не открылся. Ваши суммы сохранены.';}
  }
  function render() {
    const trip=read(),days=journeyDays(trip),day=selectedDay(trip),ticket=++sequence;
    const focused=document.activeElement?.closest('.trip-journey')?document.activeElement.name:null;
    const selection=focused && document.activeElement.type==='text'?document.activeElement.selectionStart:null;
    $('#journey-count').textContent=`${days.length} ${plural(days.length,'день','дня','дней')}`;
    $('#journey-days').replaceChildren(...days.map((row,index)=>{
      const b=button('', 'choose',row.id);b.className='journey-day';b.setAttribute('aria-pressed',String(row.id===day.id));
      b.append(el('span',`День ${index+1}`,'journey-day-number'),el('span',dateLabel(row.date),'journey-day-date'),el('span',hasTransportPlans(row)?`${row.places.length?stopsLabel(row.places.length)+' · ':''}дорога сохранена`:stopsLabel(row.places.length),'journey-day-points'));return b;
    }));
    section.querySelector('[data-journey-action="remove"]').hidden=days.length===1;
    renderForms(trip);bookings.render(trip);expenses.render(trip);expenses.pending();menuChoices.render(trip);section.dataset.budgetReady='false';
    renderTotals(trip,ticket);
    if(focused) {const field=[...section.querySelectorAll('[name]')].find(el=>el.name===focused);field?.focus({preventScroll:true});if(selection!==null)field?.setSelectionRange(selection,selection);}
  }
  for(const id of ['#journey-details','#journey-overview'])$(id).addEventListener('toggle',()=>{
    if($(id).open){section.dataset.budgetReady='false';renderTotals(read(),++sequence);}
  });
  async function choose(id) {await commit(current=>chooseTripDay(current,id),'День открыт.');section.querySelector(`[data-journey-action="choose"][data-journey-id="${id}"]`)?.focus({preventScroll:true});}
  section.addEventListener('click',async event=>{
    const node=event.target.closest('[data-journey-action]');if(!node)return;
    const action=node.dataset.journeyAction;
    if(action==='personal'){
      const day=selectedDay(read()),field=node.dataset.journeyId;
      const before=JSON.stringify(day[field]);
      const point=await pickPersonalPoint({base,initial:day[field],caption:field==='start_at'?'Откуда начнётся ваш день':'Куда вернёмся к ночи',focusPlace:catalog.poi.find(p=>p.slug===day.places[0])});
      if(!point)return;let stale=false;
      await commit(current=>{if(selectedDay(current).id!==day.id||JSON.stringify(selectedDay(current)[field])!==before){stale=true;return current;}return changeDayDetails(current,{[field]:point});},'Ваша точка сохранена.');
      feedback(stale?'День или точка уже изменились. Откройте выбор точки ещё раз.':'Точка сохранена. Первый расчёт загрузит дорожный граф; следующие работают в браузере.');return;
    }
    if(action==='choose')return choose(node.dataset.journeyId);
    if(action==='starter'){
      await commit(current=>addTripStarter(current,node.dataset.journeyId,catalog),'Готовый план стал частью вашей поездки.');
      feedback('Дни добавлены. Выберите день: меняйте остановки, время и транспорт под себя.');
      return;
    }
    const currentId=selectedDay(read()).id;
    if(action==='remove' && !window.confirm('Удалить этот день вместе с остановками, заметкой и оценками расходов? Другие дни останутся.'))return;
    await commit(current=>action==='add'?addTripDay(current):action==='copy'?addTripDay(current,true):removeTripDay(current,currentId),action==='remove'?'День удалён.':action==='copy'?'План дня скопирован. Оплаты, номера брони и связь записей с расписанием не переносятся.':'Новый день открыт.');
    section.querySelector(`[data-journey-id="${selectedDay(read()).id}"]`)?.focus({preventScroll:true});
  });
  section.addEventListener('submit',async event=>{
    const form=event.target;if(!['journey-bases','journey-costs','journey-preferences-form'].includes(form.id))return;event.preventDefault();const values=new FormData(form),day=form.dataset.day,snapshot=form._snapshot,people=form._people;let changes;
    try {
      if(form.id==='journey-preferences-form')changes={preferences:{...(selectedDay(read()).preferences || emptyPreferences()),interests:values.getAll('interest'),needs:values.getAll('need')}};
      else if(form.id==='journey-bases'){const current=selectedDay(read());changes={start_at:values.get('start_at')==='__personal__'?current.start_at:values.get('start_at') || null,night_at:values.get('night_at')==='__personal__'?current.night_at:values.get('night_at') || null,note:values.get('note')};}
      else {
        const costs=Object.fromEntries(Object.keys(COST_KINDS).map(kind=>[kind,{...selectedDay(read()).costs[kind],amount:parseKopecks(values.get(`${kind}-amount`)),quantity:Number(values.get(`${kind}-quantity`)),scope:values.get(`${kind}-scope`),basis:values.get(`${kind}-basis`),paid:parseKopecks(values.get(`${kind}-paid`))}]));
        changes={people:Number(values.get('people')),costs};
      }
    }catch(error){feedback(error.message);return;}
    let stale=false;
    await commit(current=>{if(selectedDay(current).id!==day || form.id==='journey-preferences-form' && JSON.stringify(selectedDay(current).preferences ?? null)!==snapshot || form.id==='journey-costs' && (JSON.stringify(selectedDay(current).costs)!==snapshot || dayPeople(selectedDay(current),current.itinerary?.people || 1)!==people)){stale=true;return current;}return changeDayDetails(current,changes);},'Настройки дня сохранены.');
    feedback(stale?'День или настройки уже изменились. Проверьте свежие значения и сохраните ещё раз.':form.id==='journey-preferences-form'?'Ваши пожелания сохранены.':form.id==='journey-costs'?'Ваши оценки сохранены.':'Начало, ночёвка и заметка сохранены.');
  });
  function moveControl(id,name) {
    const days=journeyDays(read()),source=selectedDay(read()).id;if(days.length<2)return null;
    const wrapper=el('label','Перенести в другой день','trip-day-move'),select=el('select');select.setAttribute('aria-label',`Перенести ${name} в другой день`);
    const none=el('option','Выберите день');none.value='';select.append(none);
    days.forEach((day,index)=>{if(day.id===selectedDay(read()).id)return;const option=el('option',`День ${index+1} · ${dateLabel(day.date)}`);option.value=day.id;select.append(option);});
    select.addEventListener('change',async()=>{const target=select.value;if(!target)return;
      await commit(current=>selectedDay(current).id===source?movePlaceToDay(current,id,target):current,`${name}: остановка перенесена.`);
      const button=section.querySelector(`[data-journey-id="${source}"]`);button?.focus({preventScroll:true});
    });wrapper.append(select);return wrapper;
  }
  return {render,moveControl,recordServiceExpense:expenses.recordService};
}
