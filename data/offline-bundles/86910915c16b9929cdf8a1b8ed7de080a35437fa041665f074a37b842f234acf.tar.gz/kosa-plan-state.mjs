import {kosaOutingCopy} from './kosa-outing.mjs?v=2026101402';
import {selectMenuChoice,removeMenuChoice} from './trip-menu-choices-state.mjs?v=2026101706';
import {savedKosaBudget,kosaBudgetText} from './kosa-budget.mjs?v=2026101305';
import {cleanTrip,emptyTrip} from './trip-state.mjs?v=2026101706';
import {mergeJourney,tripHasDraft,validTripDate,chooseTripDay,selectedDay} from './trip-days-state.mjs?v=2026101706';
import {railTable,rideSnapshot} from './trip-rail-state.mjs?v=2026101305';
import {selectKosaInterchanges,assessKosaWalking} from './kosa-interchanges.mjs?v=2026101305';
import {kosaBoarding,kosaBoardingText} from './kosa-boarding.mjs?v=2026101305';
import {kosaLightSummary} from './kosa-light.mjs?v=2026101305';
import {datedTransitInput,transitTable,pinTransitSelection} from './transport-day.mjs?v=2026101305';
import {transitHomeCopy,transitBackupCopy} from './transport-home.mjs?v=2026101305';
export const kosaClock=n=>`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
import {stationRoadOrigin} from './station-road-proof.mjs?v=2026101305';
const kosaDefaults=value=>({...value,people:value.people??1,exempt:value.exempt??0,pace:value.pace||'gentle',...(value.city==='kaliningrad'?{origin:value.origin||'home'}:{})});
const stable=value=>JSON.stringify(value,(_,row)=>row&&typeof row==='object'&&!Array.isArray(row)?Object.fromEntries(Object.keys(row).sort().map(key=>[key,row[key]])):row);
export const sameKosaAnswer=(key,a,b)=>['budget','dinner','outing'].includes(key)?stable(a)===stable(b):key==='home'?!!a&&!!b&&['ready_at','end_by','approach','return_minutes'].every(field=>a[field]===b[field]):key==='home_access'?stable(a)===stable(b):a===b;
// Reopening the same form must replay the traveller's selected train. A real
// preference change starts a new search, rather than carrying unrelated rides.
export function kosaPinnedAnswers(answers,saved){
  if(!saved?.fixed_transport)return answers;
  const selected=kosaDefaults(saved),fields=kosaDefaults(answers);
  if(Object.hasOwn(fields,'home')!==Object.hasOwn(selected,'home')||!Object.entries(fields).every(([key,value])=>sameKosaAnswer(key,value,selected[key])))return answers;
  return {...answers,fixed_transport:true,source_sha256:saved.source_sha256,bus_snapshot:saved.bus_snapshot,rail_snapshot:saved.rail_snapshot??null};
}
export function kosaRailTable(answers,catalog) {
  if(answers.city!=='kaliningrad')return null;
  if(!['kaliningrad-north-zelenogradsk','kaliningrad-south-zelenogradsk'].includes(answers.station))throw Error('Выберите вокзал Калининграда.');
  return railTable(catalog,answers.station,answers.date);
}
export function kosaInput(answers,table,catalog) {
  if(!validTripDate(answers.date) || !['zelenogradsk','kaliningrad','svetlogorsk'].includes(answers.city)
    || !['one','two'].includes(answers.walks)) throw Error('Выберите дату, город и прогулку.');
  const location=slug=>{const point=catalog?.poi?.find(p=>p.slug===slug);return point&&Number.isFinite(point.lat)&&Number.isFinite(point.lon)?{lat:point.lat,lon:point.lon}:null;};
  const input=datedTransitInput({...answers,second_visit:answers.walks==='two'?answers.second_visit:null},table,{first:location('vysota-efa'),second:location('tancuyushchiy-les')});
  const rail=kosaRailTable(answers,catalog);
  if(rail){
    if(!rail.service || (rail.reason && !['unpublished_year','outside_validity'].includes(rail.reason)) || !rail.reason && (!rail.outward || !rail.inbound))throw Error('Нет проверенной таблицы электричек на эту дату.');
    input.rail={valid_from:rail.exception?answers.date:rail.service.valid_from,valid_until:rail.exception?answers.date:rail.service.valid_until,
      publication_year:rail.exception?Number(answers.date.slice(0,4)):rail.service.publication_year,
      to_station:answers.to_station??null,from_station:answers.from_station??null,to_bus:answers.to_bus,to_train:answers.to_train,boarding:answers.rail_boarding,
      outward:(rail.outward||[]).map(r=>({...rideSnapshot(r),via:null})),inward:(rail.inbound||[]).map(r=>({...rideSnapshot(r),via:null}))};
  }
  if(answers.fixed_transport!==undefined && answers.fixed_transport!==true)throw Error('transport_selection_changed');
  if(answers.fixed_transport&&answers.source_sha256!==transitTable(table,answers.date).publication.image_sha256)throw Error('transport_selection_changed');
  return answers.fixed_transport?pinTransitSelection(input,answers.bus_snapshot,answers.rail_snapshot??null):input;
}
export function kosaNote(answers,day,table,catalog,interchanges,options={}) {
  if(day.state!=='candidate')throw Error('Для этого дня ещё нет обратного рейса.');
  table=transitTable(table,answers.date).publication;
  const rows=[`Куршская коса без машины · ${answers.date}`,
    `Город начала: ${{kaliningrad:'Калининград',zelenogradsk:'Зеленоградск',svetlogorsk:'Светлогорск'}[answers.city]}.${day.rail||day.home?'':' Дорогу до пересадки в Зеленоградске нужно проверить отдельно.'}`,
    `По таблице № 210: Зеленоградск ${kosaClock(day.outward.departure)} → Эфа ${kosaClock(day.outward.arrival)}.`,
    `На Эфу с возвращением к остановке: ${answers.first_visit} мин. Запас перед посадкой: ${answers.boarding} мин.`];
  rows.push(...kosaOutingCopy(answers.outing));
  if(day.transfer)rows.push(`Переезд: Эфа ${kosaClock(day.transfer.departure)} → Танцующий лес ${kosaClock(day.transfer.via)}. На тропу: ${answers.second_visit} мин.`);
  rows.push(`У обратной остановки не позже ${kosaClock(day.board_by)}. Автобус ${kosaClock(answers.walks==='two'?day.inward.via:day.inward.departure)} → Зеленоградск ${kosaClock(day.finish)}.`);
  if(day.backup)rows.push(`Следующий рейс по таблице: ${kosaClock(answers.walks==='two'?day.backup.via:day.backup.departure)} → Зеленоградск ${kosaClock(day.backup.arrival)}. Места и движение требуют проверки.`);
  else rows.push('После выбранного обратного рейса в этой таблице другого автобуса нет. Запасной способ возвращения нужно договорить до поездки.');
  if(day.home&&!answers.dinner)rows.push(transitHomeCopy(day.home,answers.home_access?!!answers.home_access.return_at:true,answers.home_access?.road),...(day.backup?[transitBackupCopy(day,answers.home_access?!!answers.home_access.return_at:true)]:[]));
  if(options.light!==false)rows.push(...kosaLightSummary(day.light).rows.map(row=>row.text));
  if(options.boarding!==false){
    const boarding=kosaBoarding(table,answers);
    if(boarding)rows.push(...boarding.legs.map(kosaBoardingText));
    else rows.push('Названия остановок посадки пока не загружены. Уточните их до поездки.');
  }
  if(day.rail){
    const rail=kosaRailTable(answers,catalog),r=day.rail;
    rows.splice(2,0,answers.origin==='station'?`Начало у вокзала ${rail.service.from} в ${kosaClock(r.home_start)}; у поезда к ${kosaClock(r.station_by)}. Дорога от жилья не включена.`:r.home_start===null?`Время дороги от жилья до вокзала неизвестно. У поезда к ${kosaClock(r.station_by)}.`:`Выйти из жилья в ${kosaClock(r.home_start)}. До вокзала ${r.to_station} мин ${stationRoadOrigin(answers.home_access?.road,'to')}; у поезда к ${kosaClock(r.station_by)}.`,
      `${rail.service.from}: поезд № ${r.outward.id} ${kosaClock(r.outward.departure)} → ${rail.service.to} ${kosaClock(r.outward.arrival)}. От станции до автобуса ${r.to_bus} мин по вашей оценке.`,
      `Обратно: от автобуса до поезда ${r.to_train} мин по вашей оценке; у поезда к ${kosaClock(r.train_by)}. Поезд № ${r.inward.id} ${kosaClock(r.inward.departure)} → ${rail.service.from} ${kosaClock(r.inward.arrival)}. ${answers.origin==='station'?'Дальнейшая дорога до жилья не включена.':r.from_station===null?'Дорога после поезда до жилья ещё неизвестна.':`До жилья ${r.from_station} мин; вернуться около ${kosaClock(r.home_finish)}.`}`);
    if(day.backup&&!answers.dinner)rows.push(r.backup?`После запасного автобуса: поезд ${kosaClock(r.backup.departure)} → ${kosaClock(r.backup.arrival)}.`:'После запасного автобуса подходящей электрички в этой таблице нет. Этот автобус не даёт полного запасного возвращения.');
    rows.push(`Электрички: ${rail.source.url} · сверено ${rail.source.checked_at}. ${answers.home_access?.road?'Дорога от жилья оценена по карте; пересадки и запас заданы вами. Платформы ещё не проверены.':'Подходы и запас заданы вами; пути от двери и платформы ещё не проверены.'}`);
  }
  if(answers.home_access?.road)rows.push(`Дорога от жилья: OpenStreetMap · карта от ${answers.home_access.road.source.snapshot_at.slice(0,10)} · ${answers.home_access.road.anchor.url}. До транспортной точки; вход и платформу сверьте перед выходом.`);
  if(answers.dinner)rows.push(`После автобуса: ${answers.dinner.place.name}, ${answers.dinner.walk_minutes} мин пешком и ${answers.dinner.minutes} мин на ужин. Кухню и дальнейшее возвращение смотрите в расчёте дня; поезд до добавления ужина сюда не переносится.`);
  rows.push(...kosaBudgetText(savedKosaBudget(answers)));
  const selected=selectKosaInterchanges(answers,interchanges);
  if(selected){
    const walking=assessKosaWalking(answers,selected);
    rows.push(...walking.checks.map(check=>check.text),...walking.checks.filter(check=>check.trail).map(check=>
      `${check.trail.name}: длина тропы — ${check.trail.source_url} · сверено ${check.trail.checked_at}. Темп ${check.trail.pace_kmh} км/ч и паузы — выбранная оценка, не полевое измерение.`),
      `Переходы: ${selected.source.name} · карта от ${selected.source.snapshot_at}. Площадка № 210 и последние метры ещё не проверены на месте.`);
  }else rows.push('Время переходов пока не сопоставлено с картой. Уточните его перед поездкой.');
  rows.push(`Источник: ${table.source_url} · таблица с ${table.valid_from} · сверена ${table.checked_at}.`,
    'Рейсы на дату поездки не подтверждены. Это план по опубликованной таблице, а не билет или бронь.',
    'Перед поездкой: билет категории «пешком», копия билета и расписания, вода, запасной вариант возвращения.',
    'Карты и PDF каждой тропы скачайте отдельно на godune.ru/kurshskaya-kosa/bez-mashiny/. Между тропами нет общего пешего трека.');
  return rows.join('\n');
}
export function isGeneratedKosaNote(note,answers,day,table,catalog,interchanges){
  return [{},{boarding:false},{light:false},{boarding:false,light:false}]
    .some(options=>note===kosaNote(answers,day,table,catalog,interchanges,options));
}
// Bind the two chosen trains as well as the transcribed bus publication.
export const kosaRailSnapshot=day=>day.rail?JSON.stringify([day.rail.outward,day.rail.inward]):null;
export const kosaBusSnapshot=day=>JSON.stringify([day.outward,day.transfer,day.inward]);
export const kosaMetadata=(answers,day,table)=>({version:1,...structuredClone(answers),source_sha256:transitTable(table,answers.date).publication.image_sha256,rail_snapshot:kosaRailSnapshot(day),bus_snapshot:kosaBusSnapshot(day)});
function addKosaTransitDay(current,answers,day,table,catalog,interchanges,editingDay=null) {
  const before=cleanTrip(current,catalog),note=kosaNote(answers,day,table,catalog,interchanges);
  const routes=answers.walks==='two'?['vysota-efa','tancuyushchiy-les']:['vysota-efa'];
  if(routes.some(id=>!catalog.routes.some(r=>r.slug===id)))throw Error('Прогулка пока недоступна в каталоге.');
  // Bus legs are a dated roadbook; they are never converted to a foot route.
  const metadata={...kosaMetadata(answers,day,table),generated_note:note};
  const active=before.itinerary?.days.find(d=>d.id===before.itinerary.active);
  if(answers.fixed_transport&&active?.kosa_plan?.fixed_transport&&Object.entries(kosaDefaults(metadata)).filter(([key])=>key!=='generated_note').every(([key,value])=>sameKosaAnswer(key,value,kosaDefaults(active.kosa_plan)[key])))return before;
  const same=before.itinerary?.days.find(d=>d.note===note && d.kosa_plan?.version===1
    && Object.entries(metadata).every(([key,value])=>sameKosaAnswer(key,value,d.kosa_plan[key])));
  // Saving and then exporting the same proposal must not create a second day.
  if(same)return cleanTrip(chooseTripDay({...before,routes:[...new Set([...before.routes,...routes])]},same.id),catalog);
  // Replace only the exact generated day this form previously saved or restored.
  // A changed date, another active day or a concurrent edit keeps the append path.
  const target=before.itinerary?.days.find(d=>d.id===before.itinerary.active);
  if(editingDay?.kosa_plan?.version===1&&target?.id===editingDay.id&&target.date===answers.date
    &&JSON.stringify(target)===JSON.stringify(editingDay)){
    const previousNote=target.kosa_plan.generated_note;
    const nextNote=typeof previousNote==='string'&&(target.note===previousNote||target.note.startsWith(previousNote+'\n'))
      ?note+target.note.slice(previousNote.length)
      :isGeneratedKosaNote(target.note,answers,day,table,catalog,interchanges)?note:target.note;
    const updated={...target,note:nextNote,kosa_plan:metadata,...(answers.home_access?{start_at:structuredClone(answers.home_access.start_at),night_at:structuredClone(answers.home_access.return_at),schedule:{...target.schedule,start:answers.home.ready_at,end:answers.home.end_by}}:{})};
    return cleanTrip(chooseTripDay({...before,routes:[...new Set([...before.routes,...routes])],
      itinerary:{...before.itinerary,days:before.itinerary.days.map(d=>d.id===target.id?updated:d)}},target.id),catalog);
  }
  const {party,preferences}=selectedDay(before);
  const entry={id:'day-1',date:answers.date,places:[],start_at:null,night_at:null,note,costs:{},kosa_plan:metadata,...(party?{party:structuredClone(party)}:{}),...(preferences?{preferences:structuredClone(preferences)}:{})};
  if(answers.home_access){entry.start_at=structuredClone(answers.home_access.start_at);entry.night_at=structuredClone(answers.home_access.return_at);entry.schedule={start:answers.home.ready_at,end:answers.home.end_by,reserve:15,mode:'foot',stops:{}};}
  const incoming={...emptyTrip(),date:answers.date,month:Number(answers.date.slice(5,7)),routes,...(entry.schedule?{schedule:structuredClone(entry.schedule)}:{}),
    itinerary:{version:1,active:entry.id,people:before.itinerary?.people || 1,days:[entry]}};
  const merged={...before,routes:[...new Set([...before.routes,...routes])]};
  return cleanTrip(tripHasDraft(before)?mergeJourney(before,incoming,merged):{...incoming,...(before.dreams?{dreams:before.dreams}:{})},catalog);
}

// The common menu contract is authoritative for quantities and PDF exports.
export function addKosaDay(current,answers,day,table,catalog,interchanges,editingDay=null){
  let next=addKosaTransitDay(current,answers,day,table,catalog,interchanges,editingDay);
  const old=selectedDay(current)?.kosa_plan?.dinner,record=selectedDay(next);
  const chosen=answers.dinner?.choices||[],ids=new Set(chosen.map(c=>c.menu_item_id));
  for(const c of old?.choices||[])if(!ids.has(c.menu_item_id)&&record.menu_choices?.some(v=>v.menu_item_id===c.menu_item_id))next=removeMenuChoice(next,c.menu_item_id,catalog);
  for(const c of chosen)next=selectMenuChoice(next,{...structuredClone(c),planned_date:answers.date},catalog);
  if(answers.dinner)selectedDay(next).name='Куршская коса и рыбный ужин';
  return cleanTrip(next,catalog);
}
