import {instantiateWasm} from './wasm-loader.mjs?v=1';
let engine;
// Every caller uses Rust. A failed WASM load never silently switches to different maths.
export function loadScheduler(base) {
  if (!engine) engine = fetch(new URL('assets/trip.wasm?v=19',base)).then(async response => {
    if (!response.ok) throw Error('Не удалось загрузить расчёт дня.');
    const {instance} = await instantiateWasm(response, {name:'trip'});
    const plan = input => calculate(instance.exports,input);
    plan.light = input => calculateLight(instance.exports,input);
    plan.budget = input => calculateBudget(instance.exports,input);
    plan.offers = input => calculateOffers(instance.exports,input);
    plan.housing = input => calculateHousing(instance.exports,input);
    plan.arrival = input => calculateArrival(instance.exports,input);
    plan.transitDay = input => calculateTransitDay(instance.exports,input);
    plan.transitAdvice = input => calculateTransitAdvice(instance.exports,input);
    return plan;
  }).catch(error => {engine=null;throw error;});
  return engine;
}
export const calculate = (wasm,input) => invoke(wasm,input,'trip_plan','schedule');
export const calculateLight = (wasm,input) => invoke(wasm,input,'trip_light','light');
export const calculateBudget = (wasm,input) => invoke(wasm,input,'trip_budget','budget');
export const calculateOffers = (wasm,input) => invoke(wasm,input,'trip_offers','offers');
export const calculateHousing = (wasm,input) => invoke(wasm,input,'trip_housing','housing');
export const calculateArrival = (wasm,input) => invoke(wasm,input,'trip_arrival','arrival');
export const calculateTransitDay = (wasm,input) => invoke(wasm,input,'trip_transit_day','transit_day');
export const calculateTransitAdvice = (wasm,input) => invoke(wasm,input,'trip_transit_advice','alternatives');
function invoke(wasm, input, method, key) {
  const bytes = new TextEncoder().encode(JSON.stringify(input));
  const pointer = wasm.trip_alloc(bytes.length); let output, length;
  try {
    new Uint8Array(wasm.memory.buffer,pointer,bytes.length).set(bytes);
    output = wasm[method](pointer,bytes.length);
    length = new DataView(wasm.memory.buffer).getUint32(output,true);
    const result = JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(new Uint8Array(wasm.memory.buffer,output+4,length)));
    if (!result.ok) throw Error(result.error);
    return result[key];
  } finally {
    wasm.trip_free(pointer,bytes.length);
    if (output !== undefined && length !== undefined) wasm.trip_free(output,length+4);
  }
}
