import {offlineAction} from './offline.mjs?v=2026101305';

export function initMemoryControls(catalog, base, workshop) {
  const historyButton = document.querySelector('#trip-history'), clearButton = document.querySelector('#trip-clear');
  if (!historyButton || !clearButton) return;
  historyButton.disabled = clearButton.disabled = false;
  const dialog = document.createElement('dialog'); dialog.id = 'trip-memory-dialog'; dialog.className = 'trip-link-dialog';
  dialog.setAttribute('aria-labelledby', 'trip-memory-title');
  dialog.innerHTML = `<div class="dialog-top"><p class="eyebrow">Память поездки</p><button type="button" class="icon-button" id="trip-memory-close" aria-label="Закрыть память поездки">×</button></div>
    <h2 id="trip-memory-title"></h2><p id="trip-memory-intro"></p><div id="trip-history-list"></div>
    <div id="trip-revision-preview" hidden><h3>В этой версии</h3><p id="trip-revision-date"></p><ol id="trip-revision-places"></ol><ul id="trip-revision-routes"></ul><button id="trip-revision-restore" type="button" class="button button-dark">Восстановить эту версию</button></div>
    <button id="trip-memory-backup" type="button" class="button button-outline">Скачать исходную копию</button>
    <details id="trip-planning-progress" class="wizard-evidence"><summary>Что уже получилось</summary><p id="trip-progress-count"></p><p id="trip-progress-time"></p><p>Здесь действия в инструментах этого браузера: выбор, сравнение, расчёт, сохранение и готовый PDF. Пригодный день — рассчитанный план с учтённым возвращением, показанными конфликтами и подтверждённой записью.</p><button id="trip-progress-export" type="button" class="button button-outline">Скачать сводку</button><p>Сводка хранится здесь: без названий мест, маршрутов и личных записей. Удаление памяти сайта удалит и её.</p></details>
    <div id="trip-clear-confirm" hidden><p>Исчезнут черновик и его предыдущие версии, личные точки, дата и настройки поездки, отметки на остановках, выбор города для погоды, загруженные прогулки и дорожные графы.</p><p>Скачанные вами файлы поездки и отправленные ссылки останутся у вас и у получателей. Другие устройства это действие не затронет.</p><button id="trip-clear-do" type="button" class="button button-dark">Удалить данные в этом браузере</button></div>
    <p id="trip-memory-result" role="status" aria-live="polite"></p>`;
  document.body.append(dialog);
  const $ = selector => dialog.querySelector(selector);
  let focus, selected, openedRevision, request = 0;
  const count = (value, forms) => value + ' ' + forms[value % 100 >= 11 && value % 100 <= 14 ? 2 : value % 10 === 1 ? 0 : value % 10 >= 2 && value % 10 <= 4 ? 1 : 2];
  function progress() {
    const journal=workshop.progress?.journal?.export();if(!journal)return;
    if(journal.state==='unavailable'){$('#trip-progress-count').textContent='Сводка пока недоступна. Сохранённая поездка остаётся отдельно.';$('#trip-progress-time').textContent='';return;}
    const byOrigin=new Map();
    for(const group of journal.groups){if(!byOrigin.has(group.origin))byOrigin.set(group.origin,{started:0,usable:0,saved:0,pdf:0,second:0,times:[]});const total=byOrigin.get(group.origin);total.started+=['wizard','kosa'].includes(group.source)?group.started:0;total.usable+=group.usable;total.saved+=group.saved;total.pdf+=group.pdf_ready;total.second+=group.second_day;total.times.push(...group.usable_ms);}
    const label=origin=>origin==='local_acceptance'?'Проверки разработчика':'Ваши действия';
    $('#trip-progress-count').textContent=[...byOrigin].map(([origin,s])=>`${label(origin)}: В ${s.usable} из ${s.started} начатых планов есть пригодный день. Сохранено: ${s.saved}. PDF: ${s.pdf}. Второй день: ${s.second}.`).join(' ')||'Пока нет записанных действий. Начните с мастера или дня на Куршской косе.';
    $('#trip-progress-time').textContent=[...byOrigin].filter(([,s])=>s.times.length).map(([origin,s])=>`${label(origin)}: в среднем до пригодного дня — ${Math.round(s.times.reduce((a,b)=>a+b,0)/s.times.length/1000)} сек.`).join(' ');
  }
  workshop.progress?.subscribe(progress);workshop.progress?.journal?.subscribe(progress);progress();
  $('#trip-progress-export').addEventListener('click',()=>{
    const link=document.createElement('a'),url=URL.createObjectURL(new Blob([JSON.stringify(workshop.progress.export(),null,2)],{type:'application/json'}));
    link.href=url;link.download='godune-planning-summary.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  function open(title, intro) {
    request++; focus = document.activeElement; selected = null; openedRevision = workshop.getRevision();
    $('#trip-memory-title').textContent = title; $('#trip-memory-intro').textContent = intro;
    $('#trip-memory-result').textContent = ''; $('#trip-history-list').replaceChildren();
    $('#trip-revision-preview').hidden = $('#trip-clear-confirm').hidden = true;
    $('#trip-planning-progress').hidden=false;$('#trip-planning-progress').open=false;progress();
    document.querySelectorAll('dialog[open]').forEach(node => node.close());
    dialog.showModal(); $('#trip-memory-close').focus();
  }
  $('#trip-memory-close').addEventListener('click', () => dialog.close());
  $('#trip-memory-backup').addEventListener('click', async () => {
    const button = $('#trip-memory-backup'); button.disabled = true;
    try {
      const copy = await workshop.memoryBackup(), link = document.createElement('a');
      const url = URL.createObjectURL(new Blob([JSON.stringify(copy,null,2)], {type:'application/json'}));
      link.href = url; link.download = 'godune-memory-source-'+copy.createdAt.slice(0,10)+'.json';
      link.click(); setTimeout(() => URL.revokeObjectURL(url),1000);
      $('#trip-memory-result').textContent = 'Исходная копия подготовлена: черновик и версии без преобразования.';
    } catch { $('#trip-memory-result').textContent = 'Не удалось прочитать исходную копию. Попробуйте ещё раз; данные не изменены.'; }
    finally { button.disabled = false; }
  });
  dialog.addEventListener('close', () => focus?.focus({preventScroll: true}));
  window.addEventListener('godune:memory-cleared', () => {
    request++; selected = null;
    $('#trip-history-list').replaceChildren(); $('#trip-revision-places').replaceChildren(); $('#trip-revision-routes').replaceChildren();
    $('#trip-revision-date').textContent = ''; $('#trip-revision-preview').hidden = true;
    $('#trip-revision-restore').disabled = true;
    if (dialog.open && $('#trip-clear-confirm').hidden) dialog.close();
    window.dispatchEvent(new Event('godune:offline-change'));
  });
  historyButton.addEventListener('click', async () => {
    open('Предыдущие версии поездки', workshop.memoryCompatibility()?.message || 'Можно вернуться к прежнему выбору. Текущий черновик тоже останется среди версий.');
    const token = request;
    const rows = await workshop.history();
    if (!dialog.open || token !== request) return;
    if (!rows.length) {
      $('#trip-memory-result').textContent = workshop.memoryCompatibility() ? 'Для восстановления скачайте исходную копию.' : workshop.memoryMode() === 'indexeddb' ? 'Предыдущих версий пока нет. Они появятся после изменения черновика.' : 'Браузер не открыл хранилище версий. Текущий выбор можно сохранить в файл.';
      return;
    }
    for (const row of rows) {
      const button = document.createElement('button'); button.type = 'button'; button.className = 'trip-revision-choice';
      const time = document.createElement('strong'), note = document.createElement('span');
      time.textContent = Number.isFinite(Date.parse(row.savedAt)) ? new Intl.DateTimeFormat('ru-RU', {day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Kaliningrad'}).format(new Date(row.savedAt)) : 'Версия '+row.revision;
      note.textContent = count(row.state.places.length, ['точка','точки','точек']) + ' · ' + count(row.state.routes.length, ['прогулка','прогулки','прогулок']);
      button.append(time, note);
      button.addEventListener('click', () => {
        selected = row; $('#trip-revision-preview').hidden = false;
        $('#trip-revision-date').textContent = row.state.date ? 'Дата поездки: ' + new Intl.DateTimeFormat('ru-RU', {day:'numeric', month:'long', year:'numeric', timeZone:'UTC'}).format(new Date(row.state.date+'T12:00:00Z')) : row.state.month ? 'Месяц поездки: ' + new Intl.DateTimeFormat('ru-RU', {month:'long'}).format(new Date(2027,row.state.month-1,1)) : 'Дата пока не выбрана';
        for (const kind of ['places','routes']) {
          const list = $('#trip-revision-'+kind), items = kind==='places' ? catalog.poi : catalog.routes;
          list.replaceChildren(...row.state[kind].map(id => {
            const li = document.createElement('li'); li.textContent = items.find(item=>item.slug===id)?.name || 'Место больше не входит в каталог'; return li;
          }));
        }
        $('#trip-revision-restore').disabled = false; $('#trip-memory-result').textContent = '';
      });
      $('#trip-history-list').append(button);
    }
  });
  $('#trip-revision-restore').addEventListener('click', async () => {
    if (!selected) return;
    const button = $('#trip-revision-restore'); button.disabled = true;
    const result = await workshop.setState(selected.state, 'Предыдущая версия поездки восстановлена.', {expectedRevision: openedRevision});
    $('#trip-memory-result').textContent = result.conflict ? 'Черновик изменился, пока вы смотрели версии. Закройте окно и откройте версии снова — свежий выбор сохранён.' : result.saved ? 'Эта версия стала вашим черновиком. Прежний выбор сохранён среди версий.' : 'Версия открыта в этой вкладке. Браузер не разрешил запись; сохраните поездку в файл.';
  });
  clearButton.addEventListener('click', () => {
    open('Удалить память сайта?', 'Удаление касается только этого браузера. Перед ним можно закрыть окно и сохранить поездку в файл.');
    $('#trip-clear-confirm').hidden = false; $('#trip-clear-do').disabled = false;$('#trip-planning-progress').hidden=true;
  });
  $('#trip-clear-do').addEventListener('click', async () => {
    $('#trip-clear-do').disabled = true;
    window.dispatchEvent(new Event('godune:memory-clearing'));
    let packagesRemoved = true;
    try {
      const registration = await navigator.serviceWorker?.getRegistration(new URL('.',base).href);
      if (registration?.active) await offlineAction(base, {type:'CLEAR'});
      else if ('caches' in window) for (const name of (await caches.keys()).filter(name=>name.startsWith('godune-walk-offline:')||name.startsWith('godune-routing:'))) await caches.delete(name);
    } catch { packagesRemoved = false; }
    const result = await workshop.clearMemory();
    selected = null; $('#trip-history-list').replaceChildren(); $('#trip-revision-places').replaceChildren(); $('#trip-revision-routes').replaceChildren();
    window.dispatchEvent(new Event('godune:offline-change'));
    const complete = result.fullyCleared && result.localRemoved && packagesRemoved;
    $('#trip-memory-result').textContent = complete ? 'Черновик, версии, отметки и загруженные прогулки удалены из этого браузера. Можно начать новую поездку.' : 'Не всю память удалось удалить. Браузер отказал в доступе к части данных. Попробуйте ещё раз или удалите данные godune.ru в настройках браузера.';
    $('#trip-clear-do').disabled = complete;
  });
}
